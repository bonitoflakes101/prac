/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myapplication;

/**
 *
 * @author jehan
 */
import java.sql.Connection;
import java.sql.DriverManager;

public class ConnectDB {
    
    public static Connection Connect(){
        Connection con=null;
        try {
            
            Class.forName("org.apache.derby.jdbc.EmbeddedDriver");
            con = DriverManager.getConnection("jdbc:derby://localhost:1527/BSCS2-2", "xian", "x");
            System.out.println("Connection Establish Sucessfully");
        }
        catch (Exception e){
            System.out.println(e);
        }
        return con;
    }
}
