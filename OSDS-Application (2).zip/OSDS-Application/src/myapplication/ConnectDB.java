/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package myapplication;

/**
 *
 * @author jehan
 */
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.*;

public class ConnectDB {
    
    public static Connection Connect(){
        Connection conn=null;
        try {
            //org.apache.derby.jdbc.ClientDriver
            Class.forName("org.apache.derby.jdbc.ClientDriver");
            conn = DriverManager.getConnection("jdbc:derby://localhost:1527/osds", "tristan", "osds");
            System.out.println("Connection Establish Sucessfully");
        }
        catch (Exception e){
            System.out.println(e);
        }
        return conn;
    }
}
